#-*- coding: utf-8 -*-

"""
SHIFT PROJECT libs
____________________________________________________________________________________________________
TCP lib
version : 1.0
____________________________________________________________________________________________________
This Lib contains all server-client objects of the game
____________________________________________________________________________________________________
(c) Lafiteau Franck
"""

# import external modules
from threading import Thread, Lock
from json import loads, JSONDecodeError
from socket import socket as SocketType, AF_INET, SOCK_STREAM, timeout
from queue import Queue
from uuid import uuid4, UUID
from miniupnpc import UPnP

# get main logger of the game
from . import logger

# create module types
Address = tuple[str, int]

# create module constants
LOCALHOST = ("localhost", 12345)

# create module server objects
class ClientHandler(Thread):
    """
    ClientHandler object

    This object handle the socket connection of a client

    attributs:
        - uuid: UUID = unique user id of the client
        - socket: socket = socket of the client
        - queue: Queue[tuple[UUID, dict[str, bool]]] = queue where client data are stored
        - running: bool = state of the thread
    """
    def __init__(self, uuid: UUID, client_socket: SocketType, listen_queue: Queue) -> None:
        Thread.__init__(self, name=f"Thread-of-client-{str(uuid)}")
        self.uuid: UUID = uuid
        self.socket: SocketType = client_socket
        self.queue: Queue[tuple[UUID, dict[str, bool]]] = listen_queue
        self.running: bool = True
        logger.debug(f"ClientHandler of client {str(uuid)} initialized")

    def run(self) -> None:
        """
        method called when thread is running
        """
        try:
            while self.running:
                data: bytes = self.socket.recv(2048)
                if not data:
                    logger.warning("Client closed connection")
                    self.running = False
                    break
                try:
                    logger.debug(f"Received '{data.decode()}'")
                    inputs: dict[str, bool] = loads(data.decode())
                    self.queue.put((self.uuid, inputs))
                except JSONDecodeError:
                    logger.warning("Invalid data | failed to decode")
        except (ConnectionAbortedError, ConnectionResetError, OSError):
            logger.error("Client lost connection")
        except Exception as e:
            logger.fatal(f"Unexpected error occurs: {e}")
        finally:
            self.socket.close()
            logger.debug("Close connection with client")

class ServerSocket(SocketType):
    """
    """
    def __init__(self, host: Address=LOCALHOST) -> None:
        SocketType.__init__(self, AF_INET, SOCK_STREAM)
        self.host: Address = host
        self.clients: dict[UUID, ClientHandler] = {}
        self.queue: Queue = Queue()
        self.connection_handler: ConnectionHandler = ConnectionHandler(self)
        self.running: bool = True
        self.client_lock: Lock = Lock()
        self.upnp: UPnP = UPnP()
        logger.info(f"Server initialized on {host}")

    def shutdown(self) -> None:
        """
        method called to shutdown the server properly
        """
        logger.info("Server shutdown initiated")
        self.running = False

        for handler in self.clients.values():
            handler.running = False

            try:
                handler.socket.shutdown(2)
                handler.socket.close()
            except OSError:
                pass

            handler.join()
            logger.debug(f"ClientHandler of client {str(handler.uuid)} stopped")

        logger.debug("All client threads terminated")

        self.clients.clear()
        logger.debug("Client list cleared")

        self.connection_handler.running = False
        self.connection_handler.join()

        try:
            self.close()
            logger.debug("Server socket is now closed")
        except OSError as e:
            logger.error(f"Server socket seems to be already closed: {e}")

        self.upnp.deleteportmapping(self.host[1], 'TCP')

    def send_to(self, uuid: UUID, msg: str) -> None:
        self.clients[uuid].socket.sendall(msg.encode())

    def sendall(self, msg: str) -> None:
        for client in self.clients.values():
            client.socket.sendall(msg.encode())

    def run(self) -> None:
        """
        runs the server
        """
        self.upnp.discoverdelay = 10
        self.upnp.discover()
        self.upnp.selectigd()

        self.upnp.addportmapping(self.host[1], 'TCP', self.upnp.lanaddr, self.host[1], '', '')

        external_ip = self.upnp.externalipaddress()
        logger.info(f"Port {self.host[1]} mapped to {external_ip}:{self.host[1]}")

        self.bind(self.host)
        self.settimeout(0.5)
        self.listen(5)

        self.connection_handler.start()

        logger.info("Server has started")

        while self.running:
            with self.client_lock:
                to_remove = [uuid for uuid, handler in self.clients.items() if not handler.running]
                for uuid in to_remove:
                    self.clients.pop(uuid)
                    logger.info(f"Client {uuid} removed from server list")

        self.shutdown()

class ConnectionHandler(Thread):
    """
    """
    def __init__(self, server: ServerSocket) -> None:
        Thread.__init__(self, name="Thread-of-ConnectionHandler")
        self.server: ServerSocket = server
        self.running: bool = True

    def run(self):
        """
        method called when thread is running
        """
        try:
            while self.running:
                try:
                    conn, _ = self.server.accept()
                    handler = ClientHandler(uuid4(), conn, self.server.queue)
                    with self.server.client_lock:
                        logger.info(f"Successfully added Client {str(handler.uuid)} to server list")
                        self.server.clients[handler.uuid] = handler
                    handler.start()
                    logger.debug(f"ClientHandler of client {str(handler.uuid)} started")
                except timeout:
                    continue
        except Exception as e:
            logger.fatal(f"Unexpected error occurs: {e}")
        finally:
            logger.debug("Connection thread aborted")
