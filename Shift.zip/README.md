# Shift project

---

**Project name** : Shift project  
**Authors**      : Lafiteau Franck | Castaing Guillaume  
**version**      : a0.1  

---

This project is a fanmade game where two players are playing a platformer game. One of the player is
controlling the main character trying to pass the game and the other plays his sidekick that is here
to help him during his journey

---

(c) Copyrights *Lafiteau Franck* | *Castaing Guillaume*

---
## Installation Guide

Install python version 3.13.2 or later

Then on terminal use:

```bash
python -m venv venv

.\venv\Scripts\activate

pip install -r requirements.txt

python game.py
```
